package model;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CustomerDao {
	public Serializable create(Customer customer) 
	{
		Session session = ConnectionFactory.getConnection();
		Transaction tran = session.beginTransaction();
		Serializable customerId = session.save(customer);
		tran.commit();
		session.close();
		return customerId;
	}
	public List<Customer> read() {
		Session session = ConnectionFactory.getConnection();
		Criteria criteria = session.createCriteria(Customer.class);
		return criteria.list();
	}
	public Customer read(Integer customerId) {
		Session session = ConnectionFactory.getConnection();
		return (Customer) session.get(Customer.class, customerId);
	}
	
	public int getRowsCount()
	{
		Session session = ConnectionFactory.getConnection();
		return session.createCriteria(Customer.class).list().size();
	}
	public void update(Customer arg) {
		Session session = ConnectionFactory.getConnection();
		Customer customer=(Customer) session.get(Customer.class, arg.getCustomerId());
		customer.setFirstName(arg.getFirstName());
		customer.setMiddleName(arg.getMiddleName());
		customer.setLastName(arg.getLastName());
		customer.setCity(arg.getCity());
		customer.setMobileNo(arg.getMobileNo());
		customer.setOccupation(arg.getOccupation());
		customer.setDateOfBirth(arg.getDateOfBirth());
		Transaction tran = session.beginTransaction();
		session.persist(customer);
		tran.commit();
		session.close();
	}
	public void delete(Integer customerId) {
		Session session = ConnectionFactory.getConnection();
		Customer customer = (Customer) session.get(Customer.class, customerId);
		Transaction tran = session.beginTransaction();
		session.delete(customer);
		tran.commit();
	}
	
	public List<Customer> read(int startIndex, int noOfRows)
	{
		Session session = ConnectionFactory.getConnection();
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.setFirstResult(startIndex);
		criteria.setMaxResults(noOfRows);
		return criteria.list();
	}
	
	public static void main(String[] args) {
		CustomerDao cdao=new CustomerDao();
		List<Customer> customers = cdao.read(5, 5);
		for(Customer c : customers)
			System.out.println(c);
	}
	
}
