package mla.mar_20_1.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
//@Table(name="Actor")
public class Actor {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer actorId;
	@Column(name = "FNAME")
	private String firstName;
	private String lastName;
	private Date dateOfBirth;
	@Transient	
	SimpleDateFormat sdf;
	public Actor()
	{
		sdf=new SimpleDateFormat("dd-MMM-yy");
	}
	public Actor(Integer actorId, String firstName, String lastName, Date dateOfBirth, SimpleDateFormat sdf) {
		this();
		this.actorId = actorId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.sdf = sdf;
	}
	public Actor(Integer actorId, String firstName, String lastName, String dateOfBirth, SimpleDateFormat sdf) throws ParseException {
		this();
		this.actorId = actorId;
		this.firstName = firstName;
		this.lastName = lastName;
		setDateOfBirth(dateOfBirth);
		this.sdf = sdf;
	}
	public Integer getActorId() {
		return actorId;
	}
	public void setActorId(Integer actorId) {
		this.actorId = actorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) throws ParseException {
		this.dateOfBirth=sdf.parse(dateOfBirth);
	}
	
	@Override
	public String toString() {
		return "Actor [actorId=" + actorId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ sdf.format(dateOfBirth) + "]";
	}
	
	
}
