package mla.mar_20_1;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import mla.mar_20_1.model.ConnectionFactory;
import mla.mar_20_1.model.Customer;
import mla.mar_20_1.model.Movie;
import mla.mar_20_1.model.MovieDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
     Session session = ConnectionFactory.getConnection();
     Criteria criteria = session.createCriteria(Customer.class);
     String arr[]= {"Student","Service"};
     
     criteria.add(Restrictions.in("occupation",arr));
//     criteria.add(Restrictions.isNull("middleName"));
//     criteria.add(Restrictions.eq("occupation", "Student"));
//     criteria.add(Restrictions.like("city", "%i%"));
//     criteria.addOrder(Order.desc("customerId"));
//     criteria.setFirstResult(5);
//     criteria.setMaxResults(5);
     List<Customer> customerList = criteria.list();
     for(Customer c: customerList)
    	 System.out.println(c);
    }
    
}
