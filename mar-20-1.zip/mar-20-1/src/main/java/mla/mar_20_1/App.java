package mla.mar_20_1;

import java.util.Date;
import java.util.List;

import mla.mar_20_1.model.Movie;
import mla.mar_20_1.model.MovieDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        System.out.println("Hello world");
		MovieDao mdao=new MovieDao();
		
//		Movie movie=new Movie();
//		movie.setId(221);
////		movie.setId(1);					id is auto generated. so we dont supply
//		movie.setName(" idiots");
//		movie.setReleaseDate(new Date());
//		
//		mdao.update(movie);
//		System.out.println("Check db");
    
//		
		
//		System.out.println(mdao.read(222));
		
		mdao.delete(222);
		
		List<Movie> movies = mdao.read();
		for(Movie m:movies)
			System.out.println(m);
    }
    
}
