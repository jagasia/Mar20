package mla.mar_20_1.model;

import java.io.Serializable;
import java.text.ParseException;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class ActorDao {

	public void create(Actor actor)
	{
		Session session = ConnectionFactory.getConnection();
		Transaction tran = session.beginTransaction();
		Serializable actorId = session.save(actor);
		System.out.println("Actor is created. Id genereted is "+actorId);
		tran.commit();
	}
	public static void main(String[] args) throws ParseException {
		Actor actor=new Actor();
		actor.setFirstName("Rajini");
		actor.setLastName("Kanth");
		actor.setDateOfBirth("12-Dec-1950");
		
		ActorDao adao=new ActorDao();
		adao.create(actor);
	}

}
